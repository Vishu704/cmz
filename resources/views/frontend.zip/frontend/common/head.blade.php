<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="{{ asset('img/favicon.png') }}" type="image/x-icon">
    <title>{{ $page_title }}</title>

    <!-- bootstrap links -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

    <!-- boootstrap icons CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
    <!-- custom css link -->
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">

</head>
  <body>
    
    <div class="whatsapp-call-icon">
      <a href="https://api.whatsapp.com/send?phone=91{{$user->phone}}&text="><i class="bi bi-whatsapp"></i></a>
    </div>
    <div class="phone-call-icon">
      <a href="tel:{{$user->phone}}"><i class="bi bi-telephone-fill"></i></a>
    </div>


    <header class="position-absolute w-100">
        <div class="mx-row">
            <nav class="navbar navbar-expand-lg navbar-dark">
                <div class="container-fluid">
                  <a class="navbar-brand p-0 ms-0" href="#"><img src="{{asset('uploads/logo-white.png')}}" class="img-fluid"></a>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse justify-content-end mt-auto" id="navbarNav">
                    <button class="navbar-toggler close" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="true" aria-label="Toggle navigation">
                      <i class="bi bi-x-circle"></i>
                    </button>

                    <ul class="navbar-nav me-0 pe-2">
                      <li class="nav-item">
                        <a class="nav-link px-3 active" aria-current="page" href="#">Home</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link px-3" href="#">About Us</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link px-3" href="#">Services</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link px-3" href="#">Industry Focused</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link px-3" href="#">Contact Us</a>
                      </li>
                    </ul>
                  </div>
                    <div class="phone-no m-0 position-absolute">
                      <a href="tel:{{$user->phone}}">
                          Call Now : {{$user->phone}}
                          {{-- <span class="waviy">
                            <span style="--i:1">9</span>
                            <span style="--i:2">9</span>
                            <span style="--i:3">9</span>
                            <span style="--i:4">9</span>
                            <span style="--i:5">9</span>
                            <span style="--i:6">0</span>
                            <span style="--i:7">0</span>
                            <span style="--i:8">0</span>
                            <span style="--i:9">0</span>
                            <span style="--i:10">0</span>
                          </span> --}}
                      </a>
                    </div>
                </div>
            </nav>
        </div>
    </header>