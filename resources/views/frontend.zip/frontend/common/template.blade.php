@include('frontend.common.head')

    @yield('content')

@include('frontend.common.footer')